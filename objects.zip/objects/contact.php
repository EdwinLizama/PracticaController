<?php
require_once "render/BaseLayout.php";
BaseLayout::renderHead();
BaseLayout::renderContact();
BaseLayout::renderFoot();