<?php

class RiskController
{
    public function showRisk()
    {
        require_once "models/Riskofrain.php";
        $risk = new Riskofrain();
        $showRisk = $risk->showRisk();
        require_once "views/riskofrain.php";
    }
}