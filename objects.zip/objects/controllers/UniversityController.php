<?php
class UniversityController
{
    public function showUniversity(){
        require_once "models/University.php";
        $university = new University();
        $showUniversity = $university->showUniversity();
        require_once "views/university.php";
    }
}
