<?php

class University
{
    public function showUniversity()
    {
        $universityDir = "university.php";
        
        return $universityDir;
    }
}