<?php

class Contact
{
    public function showRisk()
    {
        $riskDir = "riskofrain.php";
        
        return $riskDir;
    }
}